﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private double CalculateQ(double width, double length, double weightPerSqMeter)
        {
            return width * length * weightPerSqMeter / 1000;
        }

        private double CalculateQp(double width, double length, double weightPerSqMeter, int weatherConditions)
        {
            double q = CalculateQ(width, length, weightPerSqMeter);
            if (weatherConditions >= 5 && weatherConditions <= 8)
            {
                return q * 1.1;
            }
            else if (weatherConditions == 3 || weatherConditions == 4 || weatherConditions == 9 || weatherConditions == 10)
            {
                return q * 1.6;
            }
            else
            {
                return 1.9 * q;
            }
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void calculateButton_Click_1(object sender, EventArgs e)
        {
            double width = Convert.ToDouble(widthTextBox.Text);
            double length = Convert.ToDouble(lengthTextBox.Text);
            double weightPerSqMeter = Convert.ToDouble(weightTextBox.Text);
            int weatherConditions = Convert.ToInt32(weatherTextBox.Text);

            double q = CalculateQ(width, length, weightPerSqMeter);
            double qp = CalculateQp(width, length, weightPerSqMeter, weatherConditions);

            resultLabel.Text = "Q = " + q + "\nQp = " + qp;
        }

        private void widthTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void lengthTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
